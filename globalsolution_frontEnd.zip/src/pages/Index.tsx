

export default function Home() {

  return (
    <div> 
        <h1> teste</h1>
    </div>
  )
}