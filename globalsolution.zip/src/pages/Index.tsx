import PaginaInicial from "./Pagina_inicial"

export default function Home() {

  return (
    <div> 
        <PaginaInicial />
    </div>
  )
}